CKEDITOR.plugins.setLang( 'insertpre', 'en', {
	title : 'Insert code snippet',
	code : 'Code',
	edit : 'Edit code',
	notEmpty : 'The code field cannot be empty.'
});
