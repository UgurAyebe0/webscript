﻿CKEDITOR.plugins.setLang( 'insertpre', 'pl', {
	title : 'Wstaw kod',
	code : 'Kod',
	edit : 'Edytuj',
	notEmpty: 'Pole z kodem nie może być puste.'
});